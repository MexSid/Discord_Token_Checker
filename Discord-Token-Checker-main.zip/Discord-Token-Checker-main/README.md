# Discord-Token-Checker
Discord Token Checker schnell, kann alle gültigen Token in einer Datei speichern.
## Führen Sie den Checker aus
  `python3 main.py`
  
Sehr einfach zu bedienen, zuerst wird nach der Token-Datei gefragt, danach werden Sie gefragt, ob Sie die gültigen Token in einer Datei und in welchem ​​Ordner speichern möchten.

## Needs
* Install [Python](https://www.python.org/downloads/) (<=3.7).

![img](https://zupimages.net/up/22/16/nqwo.png)
